package com.example.mystore;

import static com.example.mystore.MainActivity.books;
import static com.example.mystore.Order.cart;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mystore.model.Book;
import com.example.mystore.model.BookInCart;

public class BookPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_page);

        ImageView bookImage = findViewById(R.id.bookPageImage);
        TextView bookTitle = findViewById(R.id.bookPageTitle);
        TextView bookWriter = findViewById(R.id.bookPageWriter);
        TextView bookPrice = findViewById(R.id.bookPagePrice);

        bookImage.setImageResource(getIntent().getIntExtra("image",0));
        bookWriter.setText(getIntent().getStringExtra("writer"));
        bookPrice.setText(getIntent().getStringExtra("price"));
        bookTitle.setText(getIntent().getStringExtra("title"));
    }

    public void addToCard(View view){
        int id = getIntent().getIntExtra("bookId",0);
        for(BookInCart book : cart) {
            if (book.getId() == id) {
                Toast.makeText(this, R.string.cart_add_error, Toast.LENGTH_LONG).show();
                return;
            }
        }
        cart.add(new BookInCart(books.get(id - 1).getId(),books.get(id-1).getAgeLimit(),books.get(id-1).getPrice(),books.get(id-1).getGenre(),books.get(id-1).getTitle(),books.get(id-1).getImg(),books.get(id-1).getWriter(),books.get(id-1).getCategory(),1));
        Toast.makeText(this, R.string.cart_add, Toast.LENGTH_LONG).show();
    }

    public void openMain(View view){
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    public void openContactInformation(View view){
        startActivity(new Intent(this, Contacts.class));
        finish();
    }

    public void openCatalog(View view){
        startActivity(new Intent(this, Catalog.class));
        finish();
    }

    public void openAboutInformation(View view){
        startActivity(new Intent(this, AboutUs.class));
        finish();
    }
}