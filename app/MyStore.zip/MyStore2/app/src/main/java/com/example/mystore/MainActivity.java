package com.example.mystore;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.mystore.adapter.CategoryAdapter;
import com.example.mystore.adapter.NoveltyAdapter;
import com.example.mystore.model.Category;
import com.example.mystore.model.Book;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    RecyclerView categoryRecycler, noveltyRecycler;
    CategoryAdapter categoryAdapter;
    static NoveltyAdapter noveltyAdapter;
    static ArrayList<Book> books = new ArrayList<>();
    static ArrayList<Book> fullBooksList = new ArrayList<>();
    static ArrayList<Book> novelties = new ArrayList<>();
    static ArrayList<Book> fullNoveltiesList = new ArrayList<>();
    static ArrayList<Category> categories = new ArrayList<>();

    static{
        Category all = new Category(1, "Всё");
        Category fiction = new Category(2, "Художественная литература");
        Category education = new Category(3, "Образование");
        Category scienceAndTechnology = new Category(4, "Наука и техника");
        Category society = new Category(5, "Общество");
        Category businessLiterature = new Category(6, "Деловая литература");
        Category psychology = new Category(7, "Психология");
        Category philosophyAndReligion = new Category(8, "Философия и религия");
        Category art = new Category(9, "Искусство");
        Category giftEditions = new Category(10, "Подарочные издания");
        Collections.addAll(categories,all, fiction, education, scienceAndTechnology, society, businessLiterature, psychology, philosophyAndReligion, art, giftEditions);


        Book kimetsuNoYaiba = new Book(1,12,689,"Манга","Клинок рассекающий \nдемонов", "kimetsu_no_yaiba","Коёхару Готогэ",2);
        Book mamasha = new Book(2,18,666,"Иронический детектив","Мамаша Бармалей", "darya_doncova","Дарья Донцова",7);
        Book blessOfSkylivers = new Book(3,16,1290,"Маньхуа","Благословение \nНебожителей", "bless","Мосян Тунсю",2);
        Book vosstanie = new Book(4,18,959,"Маньхуа","Восстание клана Чан", "vosstanie","Тянься Гуйюань",2);
        Book murderInEastExpress = new Book(5,18,324,"Детектив","Убийство в восточном \nэкспрессе","murderinexp_agatha_christie","Агата Кристи",2);
        Collections.addAll(novelties,kimetsuNoYaiba, mamasha, blessOfSkylivers, vosstanie,murderInEastExpress);
        fullNoveltiesList.addAll(novelties);

        books.addAll(novelties);
        fullBooksList.addAll(books);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setCategoryRecycler(categories);
        setNoveltyRecycler(novelties);
    }

    public void openCard (View view){
        startActivity(new Intent(this, OrderPage.class));
        finish();
    }

    public void openAboutInformation(View view){
        startActivity(new Intent(this,AboutUs.class));
        finish();
    }

    public void openContactInformation(View view){
        startActivity(new Intent(this, Contacts.class));
        finish();
    }

    public void openCatalog(View view){
        startActivity(new Intent(this, Catalog.class));
        finish();
    }

    private void setNoveltyRecycler(ArrayList<Book> novelties) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        noveltyRecycler = findViewById(R.id.noveltyRecycler);
        noveltyRecycler.setLayoutManager(layoutManager);
        noveltyAdapter = new NoveltyAdapter(this, novelties);
        noveltyRecycler.setAdapter(noveltyAdapter);
    }

    private void setCategoryRecycler(ArrayList<Category> categories) {

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        categoryRecycler = findViewById(R.id.categoryRecycler);
        categoryRecycler.setLayoutManager(layoutManager);
        categoryAdapter = new CategoryAdapter(this, categories);
        categoryRecycler.setAdapter(categoryAdapter);
    }

    public static void showNoveltiesByCategory(int category){
        novelties.clear();
        novelties.addAll(fullNoveltiesList);
        if(category!=1) {
            ArrayList<Book> sortedNoveltiesByCategory = new ArrayList<>();
            for(Book novelty : novelties){
                if(novelty.getCategory() == category){
                    sortedNoveltiesByCategory.add(novelty);
                }
            }
//            fullNoveltiesList.forEach((novelty) -> {
//                if (novelty.getCategory() == category) {
//                    sortedNoveltiesByCategory.add(novelty);
//                }
//            });
            novelties.clear();
            novelties.addAll(sortedNoveltiesByCategory);
        }
        noveltyAdapter.notifyDataSetChanged();
    }
}