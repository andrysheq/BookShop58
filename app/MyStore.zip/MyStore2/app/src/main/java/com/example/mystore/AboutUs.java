package com.example.mystore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class AboutUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
    }

    public void openMain(View view){
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    public void openContactInformation(View view){
        startActivity(new Intent(this, Contacts.class));
        finish();
    }

    public void openCatalog(View view){
        startActivity(new Intent(this, Catalog.class));
        finish();
    }
}