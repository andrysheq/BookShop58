package com.example.mystore;

import static com.example.mystore.MainActivity.categories;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.mystore.adapter.CatalogCategoryAdapter;
import com.example.mystore.model.Category;

import java.util.ArrayList;

public class Catalog extends AppCompatActivity {

    RecyclerView categoryCatalogRecycler;
    CatalogCategoryAdapter catalogCategoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
        setCategoryCatalogRecycler(categories);
    }

    public void openCard (View view){
        startActivity(new Intent(this, OrderPage.class));
        finish();
    }

    public void openAboutInformation(View view){
        startActivity(new Intent(this,AboutUs.class));
        finish();
    }

    public void openContactInformation(View view){
        startActivity(new Intent(this, Contacts.class));
        finish();
    }

    public void openMain(View view){
        startActivity(new Intent(this,MainActivity.class));
        finish();
    }

    private void setCategoryCatalogRecycler(ArrayList<Category> categories) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        categoryCatalogRecycler = findViewById(R.id.category_catalog_list);
        categoryCatalogRecycler.setLayoutManager(layoutManager);

        catalogCategoryAdapter = new CatalogCategoryAdapter(this, categories);
        categoryCatalogRecycler.setAdapter(catalogCategoryAdapter);
    }
}