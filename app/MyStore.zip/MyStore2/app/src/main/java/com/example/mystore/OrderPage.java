package com.example.mystore;

import static com.example.mystore.MainActivity.books;
import static com.example.mystore.Order.cart;
import static com.example.mystore.adapter.CartAdapter.order;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.mystore.adapter.CartAdapter;
import com.example.mystore.model.Book;
import com.example.mystore.model.BookInCart;

import java.util.ArrayList;

public class OrderPage extends AppCompatActivity {

    RecyclerView cartRecycler;
    CartAdapter cartAdapter;
    public static TextView amountOfItems;
    public static TextView finalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_page);

        setCartRecycler(cart);
    }

    private void setCartRecycler(ArrayList<BookInCart> order) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        cartRecycler = findViewById(R.id.cartRecycler);
        cartRecycler.setLayoutManager(layoutManager);
        cartAdapter = new CartAdapter(this, order);
        cartRecycler.setAdapter(cartAdapter);
        amountOfItems = findViewById(R.id.amountOfItems);
        finalPrice = findViewById(R.id.finalPrice);
    }

    public void openMain(View view){
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    public void openContactInformation(View view){
        startActivity(new Intent(this, Contacts.class));
        finish();
    }

    public void openAboutInformation(View view){
        startActivity(new Intent(this, AboutUs.class));
        finish();
    }

    public void openCatalog(View view){
        startActivity(new Intent(this, Catalog.class));
        finish();
    }

}