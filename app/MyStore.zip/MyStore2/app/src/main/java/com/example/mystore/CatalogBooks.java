package com.example.mystore;

import static com.example.mystore.MainActivity.books;
import static com.example.mystore.MainActivity.fullBooksList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.mystore.adapter.CatalogBooksAdapter;
import com.example.mystore.adapter.NoveltyAdapter;
import com.example.mystore.model.Book;

import java.util.ArrayList;

public class CatalogBooks extends AppCompatActivity {

    static CatalogBooksAdapter catalogBooksAdapter;
    RecyclerView catalogBooksRecycler;

    @SuppressLint("NotifyDataSetChanged")
    public static void showNoveltiesByCategory(int category){
        books.clear();
        books.addAll(fullBooksList);
        if(category!=1) {
            ArrayList<Book> sortedNoveltiesByCategory = new ArrayList<>();
            books.forEach((novelty) -> {
                if (novelty.getCategory() == category) {
                    sortedNoveltiesByCategory.add(novelty);
                }
            });
            books.clear();
            books.addAll(sortedNoveltiesByCategory);
        }
        if(catalogBooksAdapter!=null)
            catalogBooksAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog_books);

        setNoveltyRecycler(books);
    }

    public void openCard (View view){
        startActivity(new Intent(this, OrderPage.class));
        finish();
    }

    public void openAboutInformation(View view){
        startActivity(new Intent(this,AboutUs.class));
        finish();
    }

    public void openContactInformation(View view){
        startActivity(new Intent(this, Contacts.class));
        finish();
    }

    public void openCatalog(View view){
        startActivity(new Intent(this, Catalog.class));
        finish();
    }

    public void openMain(View view){
        startActivity(new Intent(this,MainActivity.class));
        finish();
    }

    private void setNoveltyRecycler(ArrayList<Book> novelties) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        catalogBooksRecycler = findViewById(R.id.catalog_book_list);
        catalogBooksRecycler.setLayoutManager(layoutManager);
        catalogBooksAdapter = new CatalogBooksAdapter(this, novelties);
        catalogBooksRecycler.setAdapter(catalogBooksAdapter);
    }
}