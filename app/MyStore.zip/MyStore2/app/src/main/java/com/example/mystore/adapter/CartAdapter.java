package com.example.mystore.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mystore.BookPage;
import com.example.mystore.Order;
import com.example.mystore.OrderPage;
import com.example.mystore.R;
import com.example.mystore.model.Book;
import com.example.mystore.model.BookInCart;

import java.util.ArrayList;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    Context context;
    public static ArrayList<BookInCart> order;

    public CartAdapter(Context context, ArrayList<BookInCart> order){
        this.context = context;
        this.order = order;
    }
    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View noveltyItems = LayoutInflater.from(context).inflate(R.layout.cart_item, parent, false);
        return new CartViewHolder(noveltyItems);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.noveltyTitle.setText(order.get(position).getTitle());
        holder.noveltyPrice.setText(String.valueOf(order.get(position).getPrice()) + " ₽");
        holder.noveltyWriter.setText(order.get(position).getWriter());
        holder.bookAmount.setText(String.valueOf(order.get(position).getAmount()));
        int imageId = context.getResources().getIdentifier(order.get(position).getImg(),"drawable", context.getPackageName());
        holder.noveltyImage.setImageResource(imageId);
        OrderPage.finalPrice.setText(String.valueOf(getItemsPrice()) + " ₽");
        OrderPage.amountOfItems.setText(String.valueOf(getItemsAmount()));

        holder.increaseBtn.setOnClickListener(new View.OnClickListener(){
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onClick(View view) {
                order.get(position).increaseAmount();
                notifyDataSetChanged();
            }
        });

        holder.decreaseBtn.setOnClickListener(new View.OnClickListener(){
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onClick(View view) {
                if(order.get(position).getAmount()<2){
                    order.remove(order.get(position));
                    OrderPage.finalPrice.setText(R.string.cart_check_null);
                    OrderPage.amountOfItems.setText(R.string.cart_amount_null);
                    notifyDataSetChanged();
                }else {
                    order.get(position).decreaseAmount();
                    notifyDataSetChanged();
                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, BookPage.class);

                ActivityOptions ao = ActivityOptions.makeSceneTransitionAnimation((Activity) context, new Pair<View,String>(holder.noveltyImage, "noveltyImage"));

                intent.putExtra("title", order.get(position).getTitle());
                intent.putExtra("writer", order.get(position).getWriter());
                intent.putExtra("price", String.valueOf(order.get(position).getPrice()) + " ₽");
                intent.putExtra("image", imageId);
                intent.putExtra("bookId", order.get(position).getId());
                context.startActivity(intent, ao.toBundle());
            }
        });
    }

    @Override
    public int getItemCount() {
        return order.size();
    }

    public static int getItemsPrice(){
        int res= order.stream().mapToInt(o1 -> o1.getAmount() * o1.getPrice()).sum();
        return res;
    }

    public static int getItemsAmount(){
        int res= order.stream().mapToInt(BookInCart::getAmount).sum();
        return res;
    }

    public static final class CartViewHolder extends RecyclerView.ViewHolder{

        TextView noveltyWriter;
        TextView noveltyTitle;
        TextView noveltyPrice;
        ImageView noveltyImage;
        TextView bookAmount;
        ImageButton increaseBtn;
        ImageButton decreaseBtn;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);

            increaseBtn = itemView.findViewById(R.id.plusButton);
            decreaseBtn = itemView.findViewById(R.id.minusButton);
            noveltyImage = itemView.findViewById(R.id.noveltyImage);
            bookAmount = itemView.findViewById(R.id.bookAmount);
            noveltyPrice = itemView.findViewById(R.id.noveltyPrice);
            noveltyWriter = itemView.findViewById(R.id.noveltyWriter);
            noveltyTitle = itemView.findViewById(R.id.noveltyTitle);
        }
    }
}

