package com.example.mystore;

import com.example.mystore.model.Book;
import com.example.mystore.model.BookInCart;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Order {
    static ArrayList<BookInCart> cart = new ArrayList<>();

}
