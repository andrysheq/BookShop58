package com.example.mystore.model;

public class BookInCart extends Book{
    private int amount;
    public BookInCart(int id, int ageLimit, int price, String genre, String title, String img, String writer, int category,int amount) {
        super(id, ageLimit, price, genre, title, img, writer, category);
        this.amount=amount;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public void increaseAmount(){
        this.amount++;
    }

    public void decreaseAmount(){
        this.amount--;
    }
}
