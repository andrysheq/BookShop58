package com.example.mystore.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mystore.BookPage;
import com.example.mystore.CatalogBooks;
import com.example.mystore.MainActivity;
import com.example.mystore.R;
import com.example.mystore.model.Book;
import com.example.mystore.model.Category;

import java.util.ArrayList;

public class CatalogBooksAdapter extends RecyclerView.Adapter<com.example.mystore.adapter.CatalogBooksAdapter.CatalogBooksViewHolder> {

    Context context;
    ArrayList<Book> books;

    public CatalogBooksAdapter(Context context, ArrayList<Book> books){
        this.context = context;
        this.books = books;
    }
    @Override
    public com.example.mystore.adapter.CatalogBooksAdapter.CatalogBooksViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View noveltyItems = LayoutInflater.from(context).inflate(R.layout.novelty_item, parent, false);
        return new CatalogBooksViewHolder(noveltyItems);
    }

    @Override
    public void onBindViewHolder(CatalogBooksAdapter.CatalogBooksViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.noveltyTitle.setText(books.get(position).getTitle());
        holder.noveltyPrice.setText(String.valueOf(books.get(position).getPrice()) + " ₽");
        holder.noveltyWriter.setText(books.get(position).getWriter());
        int imageId = context.getResources().getIdentifier(books.get(position).getImg(),"drawable", context.getPackageName());
        holder.noveltyImage.setImageResource(imageId);

//        holder.itemView.findViewById(R.id.asideMenu).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intentMain = new Intent(context, MainActivity.class);
//                context.startActivity(intentMain);
//            }
//        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, BookPage.class);

                ActivityOptions ao = ActivityOptions.makeSceneTransitionAnimation((Activity) context, new Pair<View,String>(holder.noveltyImage, "noveltyImage"));

                intent.putExtra("title", books.get(position).getTitle());
                intent.putExtra("writer", books.get(position).getWriter());
                intent.putExtra("price", String.valueOf(books.get(position).getPrice()) + " ₽");
                intent.putExtra("image", imageId);
                intent.putExtra("bookId", books.get(position).getId());
                context.startActivity(intent, ao.toBundle());


            }
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public static final class CatalogBooksViewHolder extends RecyclerView.ViewHolder{

        TextView noveltyWriter;
        TextView noveltyTitle;
        TextView noveltyPrice;
        ImageView noveltyImage;

        public CatalogBooksViewHolder(View itemView) {
            super(itemView);

            noveltyImage = itemView.findViewById(R.id.noveltyImage);
            noveltyPrice = itemView.findViewById(R.id.noveltyPrice);
            noveltyWriter = itemView.findViewById(R.id.noveltyWriter);
            noveltyTitle = itemView.findViewById(R.id.noveltyTitle);

        }
    }
}
