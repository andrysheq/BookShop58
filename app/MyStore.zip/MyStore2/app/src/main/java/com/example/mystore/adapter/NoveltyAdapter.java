package com.example.mystore.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mystore.BookPage;
import com.example.mystore.R;
import com.example.mystore.model.Book;

import java.util.ArrayList;

public class NoveltyAdapter extends RecyclerView.Adapter<NoveltyAdapter.NoveltyViewHolder> {

    Context context;
    ArrayList<Book> novelties;

    public NoveltyAdapter(Context context, ArrayList<Book> novelties){
        this.context = context;
        this.novelties = novelties;
    }
    @NonNull
    @Override
    public NoveltyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View noveltyItems = LayoutInflater.from(context).inflate(R.layout.novelty_item, parent, false);
        return new NoveltyViewHolder(noveltyItems);
    }

    @Override
    public void onBindViewHolder(@NonNull NoveltyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.noveltyTitle.setText(novelties.get(position).getTitle());
        holder.noveltyPrice.setText(String.valueOf(novelties.get(position).getPrice()) + " ₽");
        holder.noveltyWriter.setText(novelties.get(position).getWriter());
        int imageId = context.getResources().getIdentifier(novelties.get(position).getImg(),"drawable", context.getPackageName());
        holder.noveltyImage.setImageResource(imageId);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, BookPage.class);

                ActivityOptions ao = ActivityOptions.makeSceneTransitionAnimation((Activity) context, new Pair<View,String>(holder.noveltyImage, "noveltyImage"));

                intent.putExtra("title", novelties.get(position).getTitle());
                intent.putExtra("writer", novelties.get(position).getWriter());
                intent.putExtra("price", String.valueOf(novelties.get(position).getPrice()) + " ₽");
                intent.putExtra("image", imageId);
                intent.putExtra("bookId", novelties.get(position).getId());
                context.startActivity(intent, ao.toBundle());


            }
        });
    }

    @Override
    public int getItemCount() {
        return novelties.size();
    }

    public static final class NoveltyViewHolder extends RecyclerView.ViewHolder{

        TextView noveltyWriter;
        TextView noveltyTitle;
        TextView noveltyPrice;
        ImageView noveltyImage;

        public NoveltyViewHolder(@NonNull View itemView) {
            super(itemView);

            noveltyImage = itemView.findViewById(R.id.noveltyImage);
            noveltyPrice = itemView.findViewById(R.id.noveltyPrice);
            noveltyWriter = itemView.findViewById(R.id.noveltyWriter);
            noveltyTitle = itemView.findViewById(R.id.noveltyTitle);

        }
    }
}
